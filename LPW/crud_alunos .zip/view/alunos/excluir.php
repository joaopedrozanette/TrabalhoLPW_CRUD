<?php

//1- Receber o ID do aluno (GET)


//2- Chamar o controler para excluir


//3- Verfica se deu erro
   //3.1- SIM: exibe o erro na própria página

   //3.2- NÃO (sucesso): redireciona para o LISTAR

